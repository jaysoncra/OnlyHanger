<?php
if(isset($_POST["envoyer"])){
    $message = htmlspecialchars($_POST["POST"]);
    $insererMessage = $pdo->prepare("insert into messages(message, ")
}
?>
<form method="POST" action="">
    <textarea name="message" id="" cols="30" rows="10" minlength="1"></textarea>
    <br/><br/>
    <input type="submit" name="envoyer">
</form>

<section id="messages">


</section>